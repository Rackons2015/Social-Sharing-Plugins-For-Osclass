<?php
/*
Plugin Name: Social Sharing
Plugin URI: http://www.rackons.com
Description: Share an Item on All Social Networking including Facebook, Linkedin, Twitter, Google+, Pinterest, Digg, Delicious, Stumbleupon, Reddit, Tumblr etc. Use this social sharing plugin without javascript. Use only this Short code "<?php osc_run_hook('item_social_sharing', 'social_sharing_buttons' ); ?> wherever you want. i.e item-sidebar.php, item.php"
Version: 1.1.2
Author: Rackons
Author URI: http://rackons.com
Author Email: info@rackons.com
Short Name: social-sharing
*/

		

function social_sharing_buttons()
	{
		?>
	<style type="text/css">
		#social-sharing img{
		opacity:1.0;
		filter:alpha(opacity=100); /* For IE8 and earlier */
		}
		#social-sharing:hover img{
		opacity:0.5;
		filter:alpha(opacity=50); /* For IE8 and earlier */
		}
                 .social_block {
                 margin-bottom: 20px;padding: 20px;
                 box-shadow: none;
                background-color: #f8fbfc;
                border: 1px solid #eaeaea;  
   }        
	</style>

<div class="social_block">
      
        <h1 class="title">
          <?php _e('Share This Ad', 'social_sharing'); ?>
        </h1>
       
		 <!-- SOCIAL SHARING START -->

   
     <!-- Facebook -->
     <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo rawurlencode(osc_item_url()); ?>&t=<?php echo urlencode(osc_item_title()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/facebook.png" alt="<?php _e('Share on Facebook'); ?>" title="<?php osc_esc_html('Share on Facebook'); ?>" /></a>

     <!-- Twitter -->
     <a href="https://twitter.com/share?url=<?php echo rawurlencode(osc_item_url()); ?>&text=<?php echo urlencode(osc_item_title()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/twitter.png" alt="<?php _e('Share on Twitter'); ?>" title="<?php osc_esc_html('Share on Twitter'); ?>" /></a>

     <!-- Google+ -->
     <a href="https://plus.google.com/share?url=<?php echo rawurlencode(osc_item_url()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/google.png" alt="<?php _e('Share on Google+'); ?>" title="<?php osc_esc_html('Share on Google+'); ?>" /></a>

     <!-- Linkedin -->
     <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo rawurlencode(osc_item_url()); ?>&title=<?php echo urlencode(osc_item_title()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/linkedin.png" alt="<?php _e('Share on LinkedIn'); ?>" title="<?php osc_esc_html('Share on LinkedIn'); ?>" /></a>

    <!-- Pinterest -->
    <a href="https://pinterest.com/pin/create/button/?url=<?php echo rawurlencode(osc_item_url()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/pinterest.png" alt="<?php _e('Pin on Pinterest'); ?>" title="<?php osc_esc_html('Pin on Pinterest'); ?>" /></a>

    <!-- stumbleupon -->
    <a href="http://www.stumbleupon.com/submit?url=<?php echo rawurlencode(osc_item_url()); ?>&title=<?php urlencode(osc_item_title()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/Stumbleupon.ico" alt="<?php _e('Share on Stumbleupon'); ?>" title="<?php osc_esc_html('Share on Stumbleupon'); ?>" /></a>

    <!-- Buffer -->
    <a href="https://bufferapp.com/add?url=<?php echo rawurlencode(osc_item_url()); ?>&text=<?php echo urlencode(osc_item_title()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/buffer.png" alt="<?php _e('Share on Buffer'); ?>" title="<?php osc_esc_html('Share on Buffer'); ?>" /></a>
    
    <!-- Digg -->
    <a href="http://www.digg.com/submit?url=<?php echo rawurlencode(osc_item_url()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/diggit.png" alt="<?php _e('Share on Digg'); ?>" title="<?php osc_esc_html('Share on Digg'); ?>" /></a>
 
    <!-- Reddit -->
    <a href="http://reddit.com/submit?url=<?php echo rawurlencode(osc_item_url()); ?>&title=<?php echo osc_item_title(); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/reddit.png" alt="<?php _e('Share on Reddit'); ?>" title="<?php osc_esc_html('Share on Reddit'); ?>" /></a>
   
    <!-- Tumblr-->
    <a href="http://www.tumblr.com/share/link?url=<?php echo rawurlencode(osc_item_url()); ?>&title=<?php echo osc_item_title(); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/tumblr.png" alt="<?php _e('Share on Tumblr'); ?>" title="<?php osc_esc_html('Share on Tumblr'); ?>" /></a>
     
    <!-- Delicious-->
<a href="http://delicious.com/save" onclick="window.open('http://delicious.com/save?v=5&amp;noui&amp;jump=close&amp;url='+encodeURIComponent('<?php echo rawurlencode(osc_item_url()); ?>')+'&amp;title='+encodeURIComponent('<?php echo osc_item_title(); ?>'),'delicious', 'toolbar=no,width=550,height=550'); return false;"><img src="<?php echo osc_plugin_url(__FILE__);?>images/delicious.png" alt="<?php _e('Share on Delicious'); ?>" title="<?php osc_esc_html('Share on Delicious'); ?>" /></a>
  
    <!-- VK -->
    <a href="http://vkontakte.ru/share.php?url=<?php echo rawurlencode(osc_item_url()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/vk.png" alt="<?php _e('Share on VK'); ?>" title="<?php osc_esc_html('Share on VK'); ?>" /></a>
    
    <!-- Yummly -->
    <a href="http://www.yummly.com/urb/verify?url=<?php echo rawurlencode(osc_item_url()); ?>&title=<?php echo urlencode(osc_item_title()); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/yummly.png" alt="<?php _e('Share on Yummly'); ?>" title="<?php osc_esc_html('Share on Yummly'); ?>" /></a>

    <!-- Send to a Friend through Email -->
    <a href="<?php echo osc_item_send_friend_url(); ?>" target="_blank" id="social-sharing"><img src="<?php echo osc_plugin_url(__FILE__);?>images/email.png" alt="<?php _e('Share by email'); ?>" title="<?php osc_esc_html('Share by email'); ?>" /></a>


<!-- SOCIAL SHARING END -->
</div>
		<?php 
	}
	

function social_sharing_menu() {
    echo '<h3><a href="#">Social Sharing</a></h3>
    <ul>
        <li><a href="'.osc_admin_render_plugin_url("social_sharing/admin/help.php").'?section=types">&raquo; ' . __('Help', 'social_sharing_buttons') . '</a></li>
    </ul>';
    }

osc_add_hook('item_social_sharing', 'social_sharing_buttons', 10);
osc_add_hook('admin_menu', 'social_sharing_menu');
