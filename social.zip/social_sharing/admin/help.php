<?php
/*
Plugin Name: Social Sharing
Plugin URI: http://www.rackons.com
Description: Share an Item on All Social Networking including Facebook, Linkedin, Twitter, Google+, Pinterest, Digg, Delicious, Stumbleupon, Reddit, Tumblr etc. Use this social sharing plugin without javascript. Use only this Short code "<?php osc_run_hook('item_social_sharing', 'social_sharing_buttons' ); ?> wherever you want. i.e item-sidebar.php, item.php"
Version: 1.1.2
Author: Rackons
Author URI: http://rackons.com
Author Email: info@rackons.com
Short Name: social-sharing
*/
		?>

<div class="rac-header"> <a href="http://rackons.com/" target="_blank" class="rac_logo"> <img src="http://rackons.com/oc-content/uploads/logo.png" alt="Social Sharing Plugin" title="Social Sharing Plugin" /> </a>
  <div class="follow">
    <ul>
      <li>Follow us <i class="fa fa-hand-o-right"></i></li>
      <li><a href="http://www.facebook.com/rackonscompany" target="_blank" title="facebook"><img src="/oc-content/plugins/social_sharing/images/facebook.png" alt="<?php _e('Like us on Facebook'); ?>" title="<?php _e('Like us on Facebook'); ?>" /></a></li>
      <li><a href="http://twitter.com/rackonsdotcom" target="_blank" title="twitter"><img src="/oc-content/plugins/social_sharing/images/twitter.png" alt="<?php _e('Follow us on Twitter'); ?>" title="<?php _e('Follow us on Twitter'); ?>" /></a></li>
      <li><a href="http://plus.google.com/+RackonsCompany2015" target="_blank" title="google+"><img src="/oc-content/plugins/social_sharing/images/google.png" alt="<?php _e('Follow us on Google+'); ?>" title="<?php _e('Follow us on Google+'); ?>" /></a></li>
<li><a href="http://forums.rackons.com/osclass-plugins" target="_blank" title="Help"><img src="/oc-content/plugins/social_sharing/images/help.png" alt="<?php _e('Help'); ?>" title="<?php _e('Help'); ?>" /></a></li>
    </ul>
  </div>
</div>

<div class="clear"></div>	
<div style="padding: 20px;">
    <h1 class="title"><?php _e('Help', 'social_sharing'); ?></h1>
 <hr>
 <div>
   <h2><?php _e('What is Social Sharing Plugin?', 'social_sharing'); ?></h2>
<?php _e('This Plugin is used for Social sharing. User can share an item on all social networking site.', 'social_sharing'); ?>
</div>

<div>
   <h2><?php _e('Which Social Networking Button are using in Social Sharing plugin?', 'social_sharing'); ?></h2>
<?php _e('Buffer, Delicious, Digg, Email, Facebook, Google+, Linkedin, Pinterest, Reddit, Stumbleupon, Tumblr, Twitter, VK, Yummly.', 'social_sharing'); ?>
</div>

 <div>
   <h2><?php _e('Is it Javascript Based Plugin?', 'social_sharing'); ?></h2>
<?php _e('No, it is not javascript based plugin.', 'social_sharing'); ?>
</div>


 <div>
   <h2><?php _e('How Social Sharing Plugin Works?', 'social_sharing'); ?></h2>
<?php _e('After installed, you need to add function in item post/Sidebar file. The social sharing button will show on item page or item sidebar and when you clicked on sharing button , then that social networking site will open in new tab.', 'social_sharing'); ?>
</div>
 <div>
   <h2><?php _e('If you feel generous, you can donate to Rackons team for their excellent work.', 'social_sharing'); ?></h2>

<?php _e('If you feel VERY generous and If you find this plugin useful , you can donate to me using paypal to this email: rackons2015@gmail.com', 'social_sharing'); ?></div>

<div>
   <h2><?php _e('Function Placement', 'social_sharing'); ?></h2>
   <?php _e('Place the shortcode on any file wherever you want to show social sharing buttons, we will recommend <strong>item.php</strong> or <strong>item-sidebar.php</strong> .', 'social_sharing'); ?>
  <pre>&lt?php osc_run_hook('item_social_sharing', osc_item() ); ?&gt</pre>
</div>
</div>

<address class="rac_copy">
	<span>&copy; 2016 <a target="_blank" title="Social Sharing Plugin - Rackons.com" href="http://rackons.com/">Rackons.com</a>. All rights reserved.</span>
</address>

<style>
.rac-header{clear: both;background: #FFF;padding: 20px;height: 35px; border:1px #0f0f0f;}
.rac_logo {display: block;float:left;opacity:0.7;}
.rac_logo:hover{opacity:1;}
.follow {float:right;color: #333;}
.follow ul li:first-child {color: #333;font-weight: bold;position: relative;top: 3px;margin: 0 0 0 20px;}
.follow ul li{float: left;margin: -15px 5px 5px 5px;}
.follow li a{background-color: #333;opacity: 0.7;text-align: center;line-height: 1px;display: block;border-radius: 100%;font-size: 13px;-webkit-transition: all 0.3s ease-in-out 0s;-moz-transition: all 0.3s ease-in-out 0s;-ms-transition: all 0.3s ease-in-out 0s;-o-transition: all 0.3s ease-in-out 0s;transition: all 0.3s ease-in-out 0s;}
.follow li a:hover {opacity: 1;}
.rac_copy a{color:#018BE3!important;}
.rac_copy{font-size: 14px!important;}
</style>
